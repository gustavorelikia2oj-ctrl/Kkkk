# Gerar o APK de graça (sem instalar nada)

1. Crie uma conta grátis em github.com e um repositório novo (público).
2. Envie TODO o conteúdo desta pasta (inclusive a pasta oculta .github) para o repositório.
3. Vá na aba Actions > "Gerar APK" > Run workflow. Espere uns 5 a 10 minutos.
4. Abra a execução concluída, baixe "app-apk" em Artifacts, descompacte e instale o app-debug.apk no celular (permita instalar de fontes desconhecidas).

# Ligar a IA (grátis)
Abra o app > Configurações > cole sua chave de aistudio.google.com e salve.
Depois toque em 🎬 num produto e em "Gerar com IA".

# Alternativa sem GitHub
Hospede esta pasta (index.html na raiz) no Netlify Drop e use pwabuilder.com > Android.
